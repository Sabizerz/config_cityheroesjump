window.__require = function t(e, s, o) {
function n(a, r) {
if (!s[a]) {
if (!e[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!e[c]) {
var h = "function" == typeof __require && __require;
if (!r && h) return h(c, !0);
if (i) return i(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
a = c;
}
var p = s[a] = {
exports: {}
};
e[a][0].call(p.exports, function(t) {
return n(e[a][1][t] || t);
}, p, p.exports, t, e, s, o);
}
return s[a].exports;
}
for (var i = "function" == typeof __require && __require, a = 0; a < o.length; a++) n(o[a]);
return n;
}({
HotUpdateFirstGame: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "e94d0FNb95GWJEjpIGLpM8Y", "HotUpdateFirstGame");
var o, n = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
o(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), i = this && this.__decorate || function(t, e, s, o) {
var n, i = arguments.length, a = i < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, s) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, s, o); else for (var r = t.length - 1; r >= 0; r--) (n = t[r]) && (a = (i < 3 ? n(a) : i > 3 ? n(e, s, a) : n(e, s)) || a);
return i > 3 && a && Object.defineProperty(e, s, a), a;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = t("../Zrequire/LoadingGameZ"), r = cc._decorator, c = r.ccclass, h = r.property, p = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.versionLabel = null;
e.lbMsg = null;
e.versionFirst = "1.0.0";
e.prgBar = null;
e.btnAccept = null;
e._countClearCache = 0;
e._updating = !1;
e._canRetry = !1;
e._failCount = 0;
e._storagePath = "";
e._am = null;
e.versionCompareHandle = null;
e._customManifestStr = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.ERROR_DOMAIN_ZERO = 5;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
console.log(" ======LoadingGameZ.CONFIG_FIRST_GAME.mf======" + a.LoadingGameZ.CONFIG_FIRST_GAME.mf);
if (cc.sys.isNative) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + a.LoadingGameZ.CONFIG_FIRST_GAME.p;
console.log("======================>onFacebook===1");
this.versionCompareHandle = function(t, e) {
var s = t.split("."), o = e.split(".");
console.log("HOT UPDATE: JS Custom Version Compare: version A is " + s + ", version B is " + o);
cc.sys.localStorage.setItem("HotUpdateShowVersion_SS", JSON.stringify(t));
cc.director.emit("HotUpdateShowVersion", t);
for (var n = 0; n < s.length; ++n) {
var i = parseInt(s[n]), a = parseInt(o[n] || 0);
if (i !== a) return i - a;
}
return o.length > s.length ? -1 : 0;
};
this._am = new jsb.AssetsManager(this._customManifestStr, this._storagePath, this.versionCompareHandle);
console.log(this._am._tempVersionPath);
this._am.setVerifyCallback(function(t, e) {
var s = jsb.fileUtils.getDataFromFile(t);
if (window.md5(s) != e.md5) {
console.log("md5 is wrong, file:" + t);
return !0;
}
return !0;
});
cc.sys.os, cc.sys.OS_ANDROID, this._am.setMaxConcurrentTask(2);
this.checkUpdate();
} else this.runOnWeb();
};
e.prototype._updateLabelVersion = function() {
this.versionLabel && (this.versionLabel.string = "v:" + this._am.getLocalManifest().getVersion());
};
e.prototype.runOnWeb = function() {
this.onUpdateFinish();
};
e.prototype.onDestroy = function() {
this._am && this._am.setEventCallback(null);
this._am = null;
};
e.prototype.showLog = function(t) {
console.log("[HotUpdate===-------\x3eMAIN][showLog]----" + t);
this.lbMsg.string = t;
};
e.prototype.retry = function() {
if (!this._updating && this._canRetry) {
this._canRetry = !1;
this.showLog("Tải lại tệp lỗi...");
this._am.downloadFailedAssets();
}
};
e.prototype.updateCallback = function(t) {
var e = !1, s = !1;
console.log("event.getEventCode() ====" + JSON.stringify(t.getEventCode()));
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.errorCase = this.ERROR_DOWNLOAD;
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var o = t.getPercent();
if (isNaN(o)) return;
var n = t.getMessage();
this.disPatchRateEvent(o, n);
this.showLog("Loading: " + Math.floor(100 * o) + "%");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải xuống được manifest");
this.errorCase = this.ERROR_DOWNLOAD;
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất.");
this.prgBar.progress = 1;
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.showLog("Kết thúc cập nhật." + t.getMessage());
this.disPatchRateEvent(1);
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.showLog("Cập nhật lỗi." + t.getMessage());
this._updating = !1;
this._canRetry = !0;
this._failCount++;
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
this.showLog("Lỗi khi cập nhật");
console.log("Lỗi khi cập nhật: " + t.getAssetId() + ", " + t.getMessage());
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.showLog("Lỗi giải nén");
this.errorCase = this.ERROR_DOWNLOAD;
}
if (s) {
this._am.setEventCallback(null);
this._updating = !1;
}
if (this._canRetry) {
this.showLog("Kết nối không ổn định, đồng ý để tải lại hoặc xoá rồi cài lại");
this.btnAccept.node.active = !0;
} else this.btnAccept.node.active = s;
if (e) {
this._am.setEventCallback(null);
var i = jsb.fileUtils.getSearchPaths(), a = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(i, a);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(i));
jsb.fileUtils.setSearchPaths(i);
console.log("path game main ==========================" + jsb.fileUtils.getWritablePath());
cc.audioEngine.stopAll();
setTimeout(function() {
cc.game.restart();
}, 100);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCallback.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = new jsb.Manifest(this._customManifestStr, this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
e.prototype.checkCallback = function(t) {
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải được manifest，Skip");
this.hotUpdateFinish(!1);
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.showLog("Có một phiên bản mới và cần được cập nhật");
this._updating = !1;
this.hotUpdate();
return;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var e = t.getPercent();
if (isNaN(e)) return;
var s = t.getMessage();
this.showLog("Loading: " + e + ", msg: " + s);
return;

default:
console.log("event.getEventCode():" + t.getEventCode());
return;
}
this._am.setEventCallback(null);
this._updating = !1;
};
e.prototype.checkUpdate = function() {
if (this._updating) this.showLog("Kiểm tra các bản cập nhật..."); else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
console.log(" ======LoadingGameZ.CONFIG_FIRST_GAME.mf======" + a.LoadingGameZ.CONFIG_FIRST_GAME.mf);
var t = a.LoadingGameZ.CONFIG_FIRST_GAME.mf;
this._customManifestStr = JSON.stringify({
packageUrl: t,
remoteManifestUrl: t + "project.manifest",
remoteVersionUrl: t + "version.manifest",
version: this.versionFirst,
assets: {},
searchPaths: []
});
console.log(this._customManifestStr);
var e = new jsb.Manifest(this._customManifestStr, this._storagePath);
cc.assetManager.md5Pipe && (e = cc.assetManager.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e, this._storagePath);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCallback.bind(this));
this._am.checkUpdate();
this._updating = !0;
this.disPatchRateEvent(.01);
} else {
this.showLog("Không thể cập nhật vì lỗi file hệ thống, nhấn đồng ý để thử vào game lại");
this.errorCase = this.ERROR_CHECK_DOWNLOAD;
this.btnAccept.node.active = !0;
}
}
};
e.prototype.hotUpdateFinish = function(t) {
t ? cc.director.emit("HotUpdateFinish", t) : this.btnAccept.node.active = !0;
};
e.prototype.disPatchRateEvent = function(t, e) {
void 0 === e && (e = "");
t > 1 && (t = 1);
cc.director.emit("HotUpdateRate", t);
};
e.prototype.checkVersion = function() {
this.checkUpdate();
this.lbMsg.string = "Đang kiểm tra các bản cập nhật, vui lòng đợi";
};
e.prototype.onEnable = function() {
cc.director.on("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.on("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.on("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onDisable = function() {
cc.director.off("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.off("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.off("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onHotUpdateRate = function(t) {
var e = t;
e > 1 && (e = 1);
this.prgBar.progress = e;
this.lbMsg.string = "Cập nhật tài nguyên: " + (100 * e).toFixed(2) + "%";
};
e.prototype.onUpdateFinish = function() {
var t = this;
this.lbMsg.string = "";
cc.director.preloadScene("Game", function(e, s) {
var o = e / s;
t.lbMsg.string = "Đang tải " + o.toFixed(0) + " %";
}, function(t) {
t ? cc.error(t) : cc.director.loadScene("Game");
});
};
e.prototype.clearCache = function() {
if (this._countClearCache >= 5) {
this._countClearCache = 0;
console.log(this._countClearCache);
var t = this._storagePath;
if (!t) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(t)) throw new Error("path:--\x3e" + t + "not exist");
jsb.fileUtils.removeDirectory(t);
setTimeout(function() {
cc.game.restart();
}, 100);
}
this._countClearCache++;
};
e.prototype.onHotUpdateFinish = function() {
this.onUpdateFinish();
};
e.prototype.onClickConfirm = function() {
this.btnAccept.node.active = !1;
switch (this.errorCase) {
case this.ERROR_CHECK_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.checkUpdate();
break;

case this.ERROR_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.retry();
break;

case this.ERROR_GETINFO:
this.errorCase = this.ERROR_NO;
this.showLog("Đang kiểm tra thông tin lại");
this.checkUpdate();
break;

case this.ERROR_DOMAIN_ZERO:
this.showLog("Đang kiểm tra thông tin lại, vui lòng chờ trong giây lát");
this.checkUpdate();
}
};
i([ h(cc.Label) ], e.prototype, "versionLabel", void 0);
i([ h(cc.Label) ], e.prototype, "lbMsg", void 0);
i([ h ], e.prototype, "versionFirst", void 0);
i([ h(cc.ProgressBar) ], e.prototype, "prgBar", void 0);
i([ h(cc.Button) ], e.prototype, "btnAccept", void 0);
return i([ c ], e);
}(cc.Component);
s.default = p;
cc._RF.pop();
}, {
"../Zrequire/LoadingGameZ": "LoadingGameZ"
} ],
Https: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "0641bZfGA9DPJIaA3rIbXVE", "Https");
Object.defineProperty(s, "__esModule", {
value: !0
});
s.Https = void 0;
var o = function() {
function t() {}
t.get = function(t, e, s) {
void 0 === s && (s = !0);
var o = t, n = cc.loader.getXMLHttpRequest();
n.timeout = 5e3;
n.open("GET", o, !0);
cc.sys.isNative && n.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
s && cc.log("http request.." + o);
n.onreadystatechange = function() {
if (4 === n.readyState) if (n.status >= 200 && n.status < 300) {
var t = JSON.parse(n.responseText);
null != e && e(t);
s && cc.log("http request.." + o);
} else {
e(null);
s && cc.log("http request.." + o);
}
};
n.send();
};
t.post = function(t, e, s) {
var o = cc.loader.getXMLHttpRequest();
o.timeout = 5e3;
o.open("POST", t);
o.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
o.onreadystatechange = function() {
if (4 == o.readyState) if (o.status >= 200 && o.status < 400) {
var t = o.responseText;
s && s(o.status, t);
} else s && s(o.status, null);
};
o.send(JSON.stringify(e));
};
t.getAPI = function(t, e) {
cc.log(t);
var s = cc.loader.getXMLHttpRequest();
s.timeout = 1e3;
s.open("GET", t, !0);
cc.sys.isNative && s.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
s.onreadystatechange = function() {
if (4 === s.readyState) if (s.status >= 200 && s.status < 300) {
var t = s.responseText;
null != e && e(t);
} else e(null);
};
s.send();
};
t.getRaw = function(t, e, s) {
void 0 === s && (s = !0);
var o = cc.loader.getXMLHttpRequest();
o.timeout = 5e3;
cc.log("url:" + t);
o.open("GET", t, !0);
cc.sys.isNative && o.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
s && cc.log("http request.." + t);
o.onreadystatechange = function() {
if (4 === o.readyState) if (o.status >= 200 && o.status < 300) {
var n = JSON.parse(o.responseText);
null != e && e(n);
s && cc.log("http response.." + t);
} else {
e(null);
s && cc.log("http fail.." + t);
}
};
o.send();
};
t.getCountry = function(e) {
return new Promise(function(s) {
t.getRaw("http://ip-api.com/json", function(t) {
t && "success" == t.status && t.countryCode ? s(e && e(t.countryCode)) : s(e && e(null));
}, !1);
});
};
t.postAPI = function(t, e, s) {
var o = t;
if (0 === o.search("http://") || 0 === o.search("https://")) {
var n = new XMLHttpRequest();
n.onload = function() {
if (200 == n.status && 4 == n.readyState) {
var t = null;
try {
t = JSON.parse(n.responseText);
} catch (t) {}
s && s(t);
}
}, n.onerror = function() {
s && s(null);
}, n.timeout = 5e3, n.open("POST", o), n.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), 
n.send(e);
}
};
t.userHash = "";
t.dataPlayerInfoEgo = null;
return t;
}();
s.Https = o;
cc._RF.pop();
}, {} ],
LoadingGameZ: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "e5f902jEhxIJKnJ4KMXaL2w", "LoadingGameZ");
var o, n = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
o(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), i = this && this.__decorate || function(t, e, s, o) {
var n, i = arguments.length, a = i < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, s) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, s, o); else for (var r = t.length - 1; r >= 0; r--) (n = t[r]) && (a = (i < 3 ? n(a) : i > 3 ? n(e, s, a) : n(e, s)) || a);
return i > 3 && a && Object.defineProperty(e, s, a), a;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
s.LoadingGameZ = s.apiAhihii = void 0;
s.apiAhihii = {
g: "",
mf: "https://update.hec.vin/",
p: "remote-assets/"
};
var a = cc._decorator, r = a.ccclass, c = a.property, h = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.sceneGameIOS = null;
e.SceneGameAndroid = null;
e.SceneGameMain = null;
e.packageName = "";
e.listDMBK = [];
e.idxDomain = 0;
e.config = null;
return e;
}
o = e;
e.prototype.start = function() {
cc.log("===================start===========>");
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
o.CONFIG_FIRST_GAME = s.apiAhihii;
this.startGameMain();
};
e.prototype.startGameMain = function() {
cc.director.loadScene(this.SceneGameMain.name);
};
var o;
e.CONFIG_FIRST_GAME = null;
i([ c(cc.SceneAsset) ], e.prototype, "sceneGameIOS", void 0);
i([ c(cc.SceneAsset) ], e.prototype, "SceneGameAndroid", void 0);
i([ c(cc.SceneAsset) ], e.prototype, "SceneGameMain", void 0);
i([ c(cc.String) ], e.prototype, "packageName", void 0);
i([ c([ cc.String ]) ], e.prototype, "listDMBK", void 0);
return o = i([ r ], e);
}(cc.Component);
s.LoadingGameZ = h;
cc._RF.pop();
}, {} ],
setWV: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "93392tlGspH17XbNoxcBijk", "setWV");
var o, n = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
o(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), i = this && this.__decorate || function(t, e, s, o) {
var n, i = arguments.length, a = i < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, s) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, s, o); else for (var r = t.length - 1; r >= 0; r--) (n = t[r]) && (a = (i < 3 ? n(a) : i > 3 ? n(e, s, a) : n(e, s)) || a);
return i > 3 && a && Object.defineProperty(e, s, a), a;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = t("./LoadingGameZ"), r = cc._decorator, c = r.ccclass, h = r.property, p = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.wv = null;
e.text = "hello";
return e;
}
e.prototype.onLoad = function() {
this.wv.url = a.LoadingGameZ.CONFIG_FIRST_GAME.wv;
};
i([ h(cc.WebView) ], e.prototype, "wv", void 0);
i([ h ], e.prototype, "text", void 0);
return i([ c ], e);
}(cc.Component);
s.default = p;
cc._RF.pop();
}, {
"./LoadingGameZ": "LoadingGameZ"
} ]
}, {}, [ "Https", "LoadingGameZ", "setWV", "HotUpdateFirstGame" ]);